;mw.loader.state({"skins.cppreference2":"ready"});

/* cache key: mwiki1-mwiki_en_:resourceloader:filter:minify-js:4:23eccbe977bda0f10535556cbc890d99 */